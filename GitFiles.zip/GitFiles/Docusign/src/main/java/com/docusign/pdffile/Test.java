package com.docusign.pdffile;

public class Test {

	public static void main(String[] args) {




String docId = "918e07,454f_id,did";
StringBuffer buffer = new StringBuffer(docId);
docId = buffer.reverse().toString().replaceFirst(","," dna ");
docId = new StringBuffer(docId).reverse().toString();
System.out.println(docId);



	}

}
