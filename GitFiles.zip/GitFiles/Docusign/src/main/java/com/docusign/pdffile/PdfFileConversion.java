package com.docusign.pdffile;

import java.io.*;
import sun.misc.BASE64Decoder;

public class PdfFileConversion {

	public byte[] pdf(String args) throws IOException {
		System.out.println("Start");
		System.out.println(args);
		System.out.println("END");
		
		BASE64Decoder decoder = new BASE64Decoder();
		byte[] decodedBytes = decoder.decodeBuffer(args);
		decoder =null;
		return decodedBytes;
	}

}
