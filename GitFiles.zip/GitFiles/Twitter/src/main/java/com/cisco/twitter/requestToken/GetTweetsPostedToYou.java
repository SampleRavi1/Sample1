package com.cisco.twitter.requestToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import twitter4j.ExtendedMediaEntity;
import twitter4j.MediaEntity;
import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.UserMentionEntity;
import twitter4j.ExtendedMediaEntity.Variant;
import twitter4j.conf.ConfigurationBuilder;

public class GetTweetsPostedToYou {
	public static List<List<Object>> postedtweets(String key, String keySecret, String accesskey,
			String accesskeysecret, String screenName, String id) throws TwitterException {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(keySecret)
				.setOAuthAccessToken(accesskey).setOAuthAccessTokenSecret(accesskeysecret);
		TwitterFactory tf = new TwitterFactory(cb.build());
		Twitter twitter = tf.getInstance();
		QueryResult statuses = null;
		List<List<Object>> list = new ArrayList<List<Object>>();

		try {
			System.out.println("Showing User timeline." + id);
			System.out.println("Showing User timeline." + screenName);
			statuses = twitter.search(new Query(screenName).sinceId(Long.parseLong(id)));
			// statuses = twitter.getMentionsTimeline( new
			// Paging(Long.parseLong(id)));
		} catch (TwitterException e) {
			List<Object> l = new ArrayList<Object>();
			e.printStackTrace();
			l.add(e.getMessage());
			list.add(l);
		}
		System.out.println("Showing User timeline.");
		for (Status status : statuses.getTweets()) {
			List<Object> l = new ArrayList<Object>();

			System.out.println("status is " + status.getUserMentionEntities());
			System.out.println("Showing User timeline." + status.getRetweetCount());
			System.out.println("reply" + status.getInReplyToStatusId());
			
			
			l.add(status.getUser().getScreenName());
			UserMentionEntity[] z= status.getUserMentionEntities();
			System.out.println("getUserMentionEntities "+status.getUserMentionEntities());
			if(status.getUserMentionEntities().length>0)
			{
				for (UserMentionEntity sta : z)
			{
				System.out.println("UserScrenName "+sta.getScreenName());
				l.add(sta.getScreenName());
			}
			}
			else{
				System.out.println(""+l.add(status.getUser().getName()));
				l.add(status.getUser().getName());
			}
			
			l.add(status.getText());
			l.add(status.getId());
			l.add(status.getRetweetCount());
			l.add(status.getInReplyToStatusId());
			UserMentionEntity[] U = status.getUserMentionEntities();
			for (UserMentionEntity k : U) {
				System.out.println("userMenation" + k.getEnd());
				System.out.println("userMenation" + k.getId());
				l.add(k.getId());
			}

			MediaEntity[] m = status.getMediaEntities();
			for (MediaEntity sta : m) {
				System.out.println(sta.getMediaURL());
				l.add(sta.getMediaURL());
			}
			List<Object> list1 = new ArrayList<Object>();
			ExtendedMediaEntity[] e = status.getExtendedMediaEntities();
			for (ExtendedMediaEntity vu : e) {
				list1.add(vu.getMediaURL());
				if (vu.getVideoVariants().length > 0) {
					Variant[] vv = vu.getVideoVariants();
					String c = null;
					for (Variant vc : vv) {
						if (vc.getBitrate() > 0) {
							System.out.println("VedioUrl " + vc);
							c = vc.getUrl();
						}
					}
					l.add(c);
				}
			}
			l.add(list1);
			list.add(l);
			System.out.println("list is befor reverse" + l);
			// Collections.reverse(list);
			System.out.println("list is after reverese " + list);
		}
		Collections.reverse(list);
		return list;

	}
}