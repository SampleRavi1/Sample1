package com.cisco.twitter.requestToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterAccessToken {

	//TwitterUtil util = new TwitterUtil();

	public List<String> accessToken(String key, String keysecret, String oauthVerifier, String userId,TokenBean tokenBean)
			throws IOException {
		System.out.println("Token bean:::::::"+tokenBean);
		List<String> l = new ArrayList<String>();
		try {
			System.out.println("key" + key);
			System.out.println("secret" + keysecret);
			System.out.println("url is" + userId);

			System.out.println("verfier value is" + oauthVerifier);
			AccessToken accessToken = null;
			
			
			System.out.println("TokenBeans::::::::::::"+tokenBean);
			System.out.println("TokenBean " + tokenBean.toString());

			Twitter twitter = tokenBean.getTwitter();
			accessToken = twitter.getOAuthAccessToken(tokenBean.getRequestToken(), oauthVerifier);
			
			
			

			System.out.println("Token " + accessToken.getToken());
			System.out.println("TokenSecret" + accessToken.getTokenSecret());
			l.add(accessToken.getToken());
			l.add(accessToken.getTokenSecret());
			l.add(accessToken.getScreenName());
			l.add(String.valueOf(accessToken.getUserId()));
		} catch (Exception e) {

			e.printStackTrace();
		}
		return l;

	}

	public static String printRequest(String userId) { 

		return null;
	}
	
}
