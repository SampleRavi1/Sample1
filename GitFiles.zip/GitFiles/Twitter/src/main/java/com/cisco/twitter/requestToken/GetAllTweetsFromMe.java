package com.cisco.twitter.requestToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import twitter4j.ExtendedMediaEntity;
import twitter4j.ExtendedMediaEntity.Variant;
import twitter4j.HashtagEntity;
import twitter4j.MediaEntity;
import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.URLEntity;
import twitter4j.User;
import twitter4j.UserMentionEntity;
import twitter4j.conf.ConfigurationBuilder;

public class GetAllTweetsFromMe {
	public static List<List<Object>> alltweets(String key, String secret, String accesskey, String accessSecret,
			String screenName, String id) {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(secret).setOAuthAccessToken(accesskey)
				.setOAuthAccessTokenSecret(accessSecret);
		TwitterFactory tf = new TwitterFactory(cb.build());

		Twitter twitter = tf.getInstance();
		try {
			User user = twitter.verifyCredentials();
		} catch (TwitterException e1) {

			e1.printStackTrace();
		}
		List<Status> statuses = null;
		List<List<Object>> list = new ArrayList<List<Object>>();
		 List<List<Object>> map=new ArrayList<List<Object>>();
		try {
			statuses = twitter.getUserTimeline(screenName, new Paging(Long.parseLong(id)));
		} catch (TwitterException e) {
			List<Object> l = new ArrayList<Object>();
			e.printStackTrace();
			l.add(e.getMessage());
			list.add(l);
		}
		System.out.println("Showing User timeline.");
		for (Status status : statuses) 
		{
			List<Object> l = new ArrayList<Object>();
			
			l.add(status.getUser().getScreenName());
			l.add(status.getText());
			l.add(status.getId());
			if(status.getRetweetedStatus()!= null){
		    	System.out.println("Showing User timeline  "+status.getRetweetedStatus().getId());
		    	l.add(status.getRetweetedStatus().getId());
		    	}
		    	else
		    	{
		    		System.out.println("null");
		    		l.add(null);
		    	}
			
			UserMentionEntity[] k= status.getUserMentionEntities();
			System.out.println("getUserMentionEntities "+status.getUserMentionEntities());
			if(status.getUserMentionEntities().length>0)
			{
				for (UserMentionEntity sta : k)
			{
				System.out.println("UserScrenName "+sta.getScreenName());
				l.add(sta.getScreenName());
			}
			}
			else{
				l.add(status.getUser().getScreenName());	
			}
			
			
			
			l.add(status.getInReplyToStatusId());
			/*HashtagEntity[] h= status.getHashtagEntities();
	        for(HashtagEntity j : h)
	        {
	        	System.out.println("HashTag text "+j.getText());
	        	l.add(j.getText());
	        }*/
			MediaEntity[] m = status.getMediaEntities();
			for (MediaEntity sta : m) {
				System.out.println("Url is" + sta.getMediaURL());
				l.add(sta.getMediaURL());
			}
			
			List<Object> list1=new ArrayList<Object>();
			ExtendedMediaEntity[] e=status.getExtendedMediaEntities();
			  for(ExtendedMediaEntity vu : e) {
				 
				  System.out.println("Urls are "+vu.getMediaURL());
				  list1.add(vu.getMediaURL());
				  if(vu.getVideoVariants().length>0)
			  {
			  Variant[] vv= vu.getVideoVariants();
			  String c= null;
		        for(Variant vc : vv)
		        {
		        	if(vc.getBitrate()>0){
		        	System.out.println("VedioUrl "+vc);
		        	c=vc.getUrl();
		        	}
		        }l.add(c);
			  }
		        
		        

			// System.out.println("list is "+l);
			  }
			  l.add(list1);
			list.add(l);
			// Collections.reverse(list);
		}
		Collections.reverse(list);
		return list;

	}
}
