package com.cisco.twitter.requestToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import twitter4j.ExtendedMediaEntity;
import twitter4j.ExtendedMediaEntity.Variant;
import twitter4j.MediaEntity;
import twitter4j.Paging;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.URLEntity;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class GetReTweets {
	public static List<List<Object>> alltweets(String key, String secret, String accesskey, String accessSecret,
			String screenName, String id) {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(secret).setOAuthAccessToken(accesskey)
				.setOAuthAccessTokenSecret(accessSecret);
		TwitterFactory tf = new TwitterFactory(cb.build());

		Twitter twitter = tf.getInstance();
		try {
			User user = twitter.verifyCredentials();
		} catch (TwitterException e1) {

			e1.printStackTrace();
		}
		List<Status> statuses = null;
		List<List<Object>> list = new ArrayList<List<Object>>();
		// List<List<Object>> map=new ArrayList<List<Object>>();
		try {
			statuses = twitter.getUserTimeline(screenName, new Paging(Long.parseLong(id)));
		} catch (TwitterException e) {
			List<Object> l = new ArrayList<Object>();
			e.printStackTrace();
			l.add(e.getMessage());
			list.add(l);
		}
		System.out.println("Showing User timeline ");
		for (Status status : statuses) {
			List<Object> l = new ArrayList<Object>();
			System.out.println("status" + status.getRetweetedStatus());
			System.out.println("status" + status);
			System.out.println("Url " + status.getRetweetedStatus());
			
			l.add(status.getUser().getName());
			if (status.getRetweetedStatus() != null) {
			l.add(status.getRetweetedStatus().getText());
			}
			else
			{
				l.add(status.getText());
			}
			l.add(status.getId());
			if(status.getRetweetedStatus()!= null){
		    	
		    	l.add(status.getRetweetedStatus().getId());
		    	}
		    	else
		    	{
		    		
		    		l.add(null);
		    	}
			/*
			 * URLEntity[] m= status.getURLEntities(); for (URLEntity sta : m) {
			 * System.out.println("Url is"+sta.getExpandedURL());
			 * l.add(sta.getExpandedURL());
			 * 
			 * }
			 */
			if (status.getRetweetedStatus() != null) {
				
				MediaEntity[] me = status.getRetweetedStatus().getMediaEntities();
				for (MediaEntity su : me) {
					System.out.println("Media Url" + su.getMediaURLHttps());
					l.add(su.getMediaURL());

				}
				List<Object> list1 = new ArrayList<Object>();
				ExtendedMediaEntity[] Em = status.getRetweetedStatus().getExtendedMediaEntities();
				for (ExtendedMediaEntity vu : Em) {
					// System.out.println("ExtendedMediaEntity "+vu);
					System.out.println("Url Is " + vu.getMediaURL());
					list1.add(vu.getMediaURL());
					if (vu.getVideoVariants().length > 0) {
						Variant[] vv = vu.getVideoVariants();

						for (Variant vc : vv) {
							System.out.println("VedioUrl " + vc.getUrl());
							l.add(vc.getUrl());
						}
					}
				}
				l.add(list1);
			}
			

			// System.out.println("list is "+l);

			list.add(l);
		}

		Collections.reverse(list);
		return list;

	}

}
