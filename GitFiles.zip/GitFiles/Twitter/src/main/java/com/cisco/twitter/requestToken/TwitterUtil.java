package com.cisco.twitter.requestToken;

import java.io.*;
import java.util.List;

import sun.misc.BASE64Decoder;
import twitter4j.Twitter;
import twitter4j.auth.RequestToken;

public class TwitterUtil implements Serializable {

	public TokenBean getTokenBean(RequestToken requestToken, Twitter twitter, String userId) {
		TokenBean tokenBean = new TokenBean(requestToken, System.currentTimeMillis(), twitter, userId);
		return tokenBean;
	}

	@SuppressWarnings("unchecked")
	public TokenBean toConvertIntoObject(String token) {
		
		try {
		BASE64Decoder decoder = new BASE64Decoder();
		byte[] buffer = decoder.decodeBuffer(token);
		decoder =null;

			/*byte[] buffer;
		
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(token);
			buffer = bos.toByteArray();*/

			System.out.println("Token Type  " + token.getClass());
			TokenBean tokenBean = null;
			System.out.println("token  " + buffer);
			// byte[] data = token.getBytes();
			ByteArrayInputStream baip = new ByteArrayInputStream(buffer);
			System.out.println("baip   " + baip);
			ObjectInputStream ois = new ObjectInputStream(baip);
			tokenBean=(TokenBean)ois.readObject();
			

			return tokenBean;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		/*
		 * InputStream stream = (InputStream) list.get(0); ObjectInputStream
		 * ois=null; try{ ois = new ObjectInputStream(stream); return
		 * (TokenBean) ois.readObject(); } catch(Exception e){
		 * e.printStackTrace(); }finally { try { ois.close(); } catch
		 * (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } } return null;
		 */

	}
}
