package com.cisco.twitter.requestToken;

import java.util.ArrayList;
import java.util.List;
import twitter4j.Paging;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class GetTweetsFromMe {

	public static List<List<Object>> tweets(String key, String keySecret, String accesskey, String accesskeysecret,
			String name) {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(keySecret)
				.setOAuthAccessToken(accesskey).setOAuthAccessTokenSecret(accesskeysecret);
		TwitterFactory tf = new TwitterFactory(cb.build());

		Twitter twitter = tf.getInstance();
		try {
			User user = twitter.verifyCredentials();
		} catch (TwitterException e1) {

			e1.printStackTrace();
		}
		QueryResult statuses = null;
		
		List<List<Object>> list = new ArrayList<List<Object>>();
		List<Object> map = new ArrayList<Object>();
		try {
			statuses = twitter.search(new Query(name));
		} catch (TwitterException e) {

			e.printStackTrace();
			
		}
		System.out.println("Showing User timeline."+statuses.getMaxId());
		map.add(statuses.getMaxId());
		/*for (Status status : statuses) {
			System.out.println(status.getUser().getScreenName() + ":" + status.getText() + ":" + status.getId() + ":"
					+ status.getQuotedStatusId());
			map.add(status.getUser().getScreenName());
			map.add(status.getText());
			map.add(status.getId());
			map.add(status.getQuotedStatusId());
			

		}*/
		list.add(map);
		return list;

	}
}
