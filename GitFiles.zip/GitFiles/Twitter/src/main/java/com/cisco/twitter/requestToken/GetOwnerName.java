package com.cisco.twitter.requestToken;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class GetOwnerName {
	public static String getOwner(String key, String keySecret, String accesskey, String accesskeysecret, String id) {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(keySecret)
				.setOAuthAccessToken(accesskey).setOAuthAccessTokenSecret(accesskeysecret);
		TwitterFactory tf = new TwitterFactory(cb.build());

		Twitter twitter = tf.getInstance();
		User statuses = null;
		try {
			statuses = twitter.showUser(Long.parseLong(id));
		} catch (TwitterException e) {

			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("Showing User timeline.");
		return statuses.getScreenName();
	}
}
