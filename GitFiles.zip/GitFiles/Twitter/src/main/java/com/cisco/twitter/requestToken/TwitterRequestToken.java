package com.cisco.twitter.requestToken;

import java.util.ArrayList;

import org.codehaus.jettison.json.JSONObject;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.RequestToken;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterRequestToken {

	public TokenBean requestToken(String key, String keysecret, String userId, String redirectUrl) {
		//List<TwitterUtil> l = new ArrayList<TwitterUtil>();
		

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(keysecret);

		TwitterFactory tf = new TwitterFactory(cb.build());
		Twitter twitter = tf.getInstance();

		
		RequestToken requestToken=null;
		try {
				requestToken = twitter.getOAuthRequestToken(redirectUrl);
			
			System.out.println(requestToken.getAuthenticationURL());
			System.out.println(twitter.getAuthorization());
			System.out.print("twitter========"+twitter);
		
			
			//l.add(requestToken);
			
			
			/*l.add(requestToken.getTokenSecret());
			l.add(requestToken.getAuthorizationURL());
			l.add(requestToken.getAuthenticationURL());*/
			
			

		} catch (TwitterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		TwitterUtil util = new TwitterUtil();
		//util.getTokenBean(requestToken, twitter, userId);
		
		return util.getTokenBean(requestToken, twitter, userId);
		
	}

}
