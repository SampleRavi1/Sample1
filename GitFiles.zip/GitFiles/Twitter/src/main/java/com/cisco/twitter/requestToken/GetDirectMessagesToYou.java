package com.cisco.twitter.requestToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import twitter4j.DirectMessage;
import twitter4j.MediaEntity;
import twitter4j.Paging;
import twitter4j.ResponseList;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.URLEntity;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

public class GetDirectMessagesToYou {
	public static List<Object> GetMessages(String key, String secret, String accesskey, String accessSecret, String id) {

		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true).setOAuthConsumerKey(key).setOAuthConsumerSecret(secret).setOAuthAccessToken(accesskey)
				.setOAuthAccessTokenSecret(accessSecret);
		TwitterFactory tf = new TwitterFactory(cb.build());

		Twitter twitter = tf.getInstance();
		try {
			User user = twitter.verifyCredentials();
		} catch (TwitterException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}

		ResponseList<DirectMessage> statuses = null;
		//List<Object> l = new ArrayList<Object>();
		List<Object> list = new ArrayList<Object>();
		try {
			statuses = twitter.getDirectMessages(new Paging(Long.parseLong(id)));
		} catch (TwitterException e) {
			// TODO Auto-generated catch block
			List<Object> l = new ArrayList<Object>();
			e.printStackTrace();
			l.add(e.getMessage());
			list.add(l);
		}

		for (DirectMessage s : statuses) {
			List<Object> l = new ArrayList<Object>();
			System.out.println("DirectMessage " + s.getText());
			System.out.println("DirectMessage " + s.getSenderScreenName());
			l.add(s.getId());
			l.add(s.getText());
			l.add(s.getSenderScreenName());
			l.add(s.getRecipientScreenName());

			URLEntity[] m = s.getURLEntities();
			for (URLEntity k : m) {
				System.out.println("Url" + k.getExpandedURL());
				l.add(k.getExpandedURL());
			}
			list.add(l);
			}
		Collections.reverse(list);
		return list;
		

	}

}
