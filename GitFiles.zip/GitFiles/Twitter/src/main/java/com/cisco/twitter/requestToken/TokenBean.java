package com.cisco.twitter.requestToken;

import java.io.Serializable;

import twitter4j.Twitter;
import twitter4j.auth.RequestToken;

public class TokenBean implements Serializable{

	private RequestToken requestToken;
	private long time;
	private Twitter twitter;
	private String userId;
	
	


	public TokenBean(RequestToken requestToken, long time, Twitter twitter, String userId) {
		super();
		this.requestToken = requestToken;
		this.time = time;
		this.twitter = twitter;
		this.setUserId(userId);
	}

	public RequestToken getRequestToken() {
		return requestToken;
	}

	public void setRequestToken(RequestToken requestToken) {
		this.requestToken = requestToken;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	
	public Twitter getTwitter() {
		return twitter;
	}

	public void setTwitter(Twitter twitter) {
		this.twitter = twitter;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "TokenBean [requestToken=" + requestToken + ", time=" + time + ", twitter=" + twitter + ", userId="
				+ userId + "]";
	}

	


}
